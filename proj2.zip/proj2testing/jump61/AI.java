package jump61;

import java.util.ArrayList;

/** An automated Player.
 *  @author Iskander Rakhmanberdiyev
 */
class AI extends Player {

    /** A new player of GAME initially playing COLOR that chooses
     *  moves automatically.
     */
    AI(Game game, Color color) {
        super(game, color);
        // FIXME
    }

    @Override
    void makeMove() {
        // FIXME
    }

    /** Return the minimum of CUTOFF and the minmax value of board B
     *  (which must be mutable) for player P to a search depth of D
     *  (where D == 0 denotes evaluating just the next move).
     *  If MOVES is not null and CUTOFF is not exceeded, set MOVES to
     *  a list of all highest-scoring moves for P; clear it if
     *  non-null and CUTOFF is exceeded. the contents of B are
     *  invariant over this call. */
    private int minmax(Color p, Board b, int d, int cutoff,
        ArrayList<Integer> moves) {
        return 0;
        // FIXME
    }

    /** Returns heuristic value of board B for player P.
     *  Higher is better for P. */
    private int staticEval(Color p, Board b) {
        return 0;
        // FIXME
    }

}


