package jump61;


/** The suite of all JUnit tests for the Text Formatter.
 *  @author
 */
public class UnitTest {

    /** Run the JUnit tests in the tex61 package. */
    public static void main(String[] ignored) {
        // textui.runClasses(jump61.BoardTest.class);
        // Add other .class arguments to the call above.
    }

}


